using System;

namespace BookStore_API.Domain.DTO
{
    public class WishListDTO
    {
        public int WishID { get; set; }
    }
}