using System;

namespace BookStore_API.Domain.DTO
{
    public class WishListReadDTO
    {
        public int WishID { get; set; }
    }
}