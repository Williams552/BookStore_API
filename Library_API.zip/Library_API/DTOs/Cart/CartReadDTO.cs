using System;

namespace BookStore_API.Domain.DTO
{
    public class CartReadDTO
    {
        public int CartID { get; set; }
    }
}