using System;

namespace BookStore_API.Domain.DTO
{
    public class CartDTO
    {
        public int CartID { get; set; }
    }
}